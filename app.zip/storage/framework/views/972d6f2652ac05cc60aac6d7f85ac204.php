<?php $__env->startSection('title', 'CAC - ' . $movie->title); ?>
<div style="background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('<?php echo e($background); ?>')"
    class="relative min-h-screen bg-cover bg-center p-10 place-content-center">
    <div class="grid md:grid-cols-[auto_auto] gap-x-10 self-center mb-7 lg:mb-3">
        <div>
            <img src="<?php echo e('https://image.tmdb.org/t/p/original' . $movie->poster_path); ?>" alt=""
                class="md:w-96 w-full drop-shadow-[0px_2px_10px_rgba(255,255,255,0.50)]">
        </div>
        
        <div class="text-xl text-white text-justify mt-12 md:mt-0">
            
            <h1 class="text-3xl text-yellow-200 font-semibold mb-5"><?php echo e($movie->original_title); ?></h1>
            
            <h2 class="text-2xl text-yellow-200 font-semibold mb-5"><?php echo e($movie->title); ?></h2>
            
            <h3><span class="text-gray-300">Estreno:</span>
                <?php echo e(\Carbon\Carbon::parse($movie->release_date)->format('d/m/Y')); ?> </h3>
            
            <span class="block my-3">
                <!--[if BLOCK]><![endif]--><?php if($movie->vote_count <= 500): ?>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                <?php elseif($movie->vote_count > 500 && $movie->vote_count <= 1000): ?>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                <?php elseif($movie->vote_count > 1000 && $movie->vote_count <= 2500): ?>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                <?php elseif($movie->vote_count > 2500 && $movie->vote_count <= 5000): ?>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                <?php elseif($movie->vote_count > 5000): ?>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                    <i class="fa-solid fa-star text-yellow-400 text-sm"></i>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </span>
            
            <p class="mt-2">
                <span class="text-gray-300">Pais de Origen:</span>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $movie->production_countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if($index != count($movie->production_countries) - 1): ?>
                        <span><?php echo e($country->name); ?> | </span>
                    <?php else: ?>
                        <span><?php echo e($country->name); ?></span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </p>
            
            <p class="mt-2">
                <span class="text-gray-300">Genéro: </span>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $movie->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if($index != count($movie->genres) - 1): ?>
                        <span><?php echo e($genre->name); ?> | </span>
                    <?php else: ?>
                        <span><?php echo e($genre->name); ?></span>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </p>
            
            <p class="mt-2">
                <span>
                    
                    <span class="text-gray-300">Idiomas: </span>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $movie->spoken_languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($index != count($movie->spoken_languages) - 1): ?>
                            <span><?php echo e($language->name); ?> | </span>
                        <?php else: ?>
                            <span><?php echo e($language->name); ?></span>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </span>
                
                <span class="ms-4">
                    <span class="text-gray-300">Duración: </span>
                    <?php echo e($movie->runtime); ?> min
                </span>
            </p>
            
            <p class="mt-2"><span class="text-gray-300">Presupuesto:
                </span>$ <?php echo e(number_format($movie->budget, 2, ',', '.')); ?>

            </p>
            
            <p class="mt-4"><span class="text-gray-300">Resumen:</span>
            <p class="mt-2"><?php echo e($movie->overview); ?></p>
            </p>
            <div class="absolute lg:bottom-4 lg:right-10 bottom-2 right-2">
                <button
                    class="flex items-center justify-between px-4 py-2 bg-gray-800 hover:bg-gray-900 drop-shadow-[0px_0px_2px_rgba(255,255,250,0.75)]"
                    wire:click='goBack'><i class="fa-solid fa-caret-left"></i></button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\laravel\example-app\resources\views/livewire/movies/movie-detail.blade.php ENDPATH**/ ?>